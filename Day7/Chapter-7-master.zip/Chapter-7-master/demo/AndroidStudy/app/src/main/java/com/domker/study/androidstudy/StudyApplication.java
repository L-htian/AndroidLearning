package com.domker.study.androidstudy;

import android.app.Application;

/**
 * Created by wanlipeng on 2019-07-05 16:51
 */
public class StudyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}
