# Chapter-1
第一讲 Android 基础

包含了以下内容：

1. ppt - 本地课程的讲义
2. assignment - 本次课程的壳 demo，可以 clone 下来运行，以 demo 配置的环境为准

Android Studio 的配置环境

- Android Studio：3.4.1
- Gradle：5.1.1
- Gradle Plugin：3.4.1
- AppCompat-V7：28.0.0
- ConstraintLayout：1.1.3
- compileSdkVersion/targetSdkVersion：28


