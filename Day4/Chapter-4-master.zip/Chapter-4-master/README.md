# Chapter-4
第四讲 复杂应用组件 Handler机制、多线程、 自定义View

包含了以下内容

1. ppt - 本地课程的讲义
2. assignment - 本次课程的作业：绘制一个桌面时钟，在Clock.java类中完成todo部分

